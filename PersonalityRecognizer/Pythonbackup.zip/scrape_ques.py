from BeautifulSoup import BeautifulSoup
from nltk.corpus import stopwords
from nltk.stem.porter import *
import subprocess
import shlex


def run_command(cmd):
    cmd = shlex.split(cmd)
    return subprocess.check_output(cmd).decode('ascii')

# walk_dir = "/home/saurabh/IR_Project/quora_dataset"
#
# root, subdirs, files = os.walk(walk_dir)
# print root


stop = stopwords.words('english')
stop.append(['.', ',', '"', "'", '?', '!', ':', ';', '(', ')', '[', ']', '{', '}', ' '])

#print [i for i in sentence.split() if i not in stop]
fileList = ['0', '1', '2', '3', '4']
for i in fileList:
    filename = "/home/saurabh/IR_Project/quora_dataset/3/" + i
    # for filename in root[1:]:
    f = open(filename, 'r')
    filecontent = f.read()

    #print(filecontent)

    soup = BeautifulSoup(filecontent)
    #print soup.prettify()
    topicTag = soup.find('span', attrs={'class': 'TopicNameSpan TopicName'})
    titleTag = soup.find('span', attrs={'class': 'rendered_qtext'})
    detailsTag = soup.find('div', attrs={'class': 'question_details'})
    [s.extract() for s in detailsTag('a')]
    #print detailsTag.prettify()
    # re.sub(r'<*>', ' ', detailsTag)
    question = str(titleTag) + str(detailsTag)
    refined_ques = re.sub('<.*?>', '', str(question))
    refined_ques = refined_ques.replace("'", "")
    refined_ques = refined_ques.replace(".", " ")
    print refined_ques
    filename = "/home/saurabh/IR_Project/quora_dataset/3/"+i+"_ques"
    f = open(filename, 'w')
    f.write(refined_ques)
    f.close()

    output = run_command('./PersonalityRecognizer -i ' + filename + ' -t 2 -m 4')
    #output = run_command('./PersonalityRecognizer -i test.txt -t 2 -m 4')
    print output

    cmdfilename = "/home/saurabh/IR_Project/quora_dataset/3/tmp"+i
    f = open(cmdfilename, 'w')
    f.write(output)
    f.close()
    data = []
    with open(cmdfilename) as f:
        for line in f:
            if line.startswith("Self-assessed"):
                num = re.findall(r"[-+]?\d*\.\d+|[-+]?\d+", line)
                data.append(float(num[0]))

    print data

#re.findall("\d+\.\d+",data)
# scores = re.findall(r'^Self-assessed\w+', output)
# print scores

'''
tokens = [i for i in refined_ques.split() if i not in stop]
#tokens.remove("It\xe2\x80\x99s")
tokens = list(set(tokens))
print tokens
stemmer = PorterStemmer()
#stemmer = SnowballStemmer("english")
stem_tokens = [stemmer.stem(token.decode('utf-8')) for token in tokens]
stem_tokens = [stem_token.encode('utf-8') for stem_token in stem_tokens]
print stem_tokens
# f = open(filename, 'r')
# f.write(tokens)
# print newDiv
'''
# print detailsTag.prettify()

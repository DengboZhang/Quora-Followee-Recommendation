import subprocess
import shlex


def run_command(cmd):
    cmd = shlex.split(cmd)
    return subprocess.check_output(cmd).decode('ascii')

print(run_command('./PersonalityRecognizer -i examples -d -t 2 -m 4'))

out_bytes = subprocess.check_output(["ls","-ltr"])
print out_bytes
out_bytes = subprocess.check_output("PersonalityRecognizer", "-i examples", "-d", "-t 2", "-m 4")
print out_bytes
